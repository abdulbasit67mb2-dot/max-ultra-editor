package com.maxultra.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.maxultra.editor.ui.screens.*
import com.maxultra.editor.ui.theme.MaxUltraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaxUltraTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var currentScreen by remember { mutableStateOf("home") }
                    var activeMediaUri by remember { mutableStateOf<Uri?>(null) }

                    when (currentScreen) {
                        "home" -> HomeScreen(
                            onNavigate = { route, uri ->
                                activeMediaUri = uri
                                currentScreen = route
                            }
                        )
                        "photo_editor" -> activeMediaUri?.let {
                            PhotoEditorScreen(it, onBack = { currentScreen = "home" })
                        }
                        "ai_enhancer" -> activeMediaUri?.let {
                            AiEnhancerScreen(it, onBack = { currentScreen = "home" })
                        }
                        "object_eraser" -> activeMediaUri?.let {
                            ObjectEraserScreen(it, onBack = { currentScreen = "home" })
                        }
                        "bg_studio" -> activeMediaUri?.let {
                            BackgroundStudioScreen(it, onBack = { currentScreen = "home" })
                        }
                        "video_editor" -> activeMediaUri?.let {
                            VideoEditorScreen(it, onBack = { currentScreen = "home" })
                        }
                    }
                }
            }
        }
    }
}
