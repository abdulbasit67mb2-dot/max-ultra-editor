package com.maxultra.editor.ui.screens
import android.net.Uri
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun VideoEditorScreen(videoUri: Uri, onBack: () -> Unit) { Text("Video Editor") }
