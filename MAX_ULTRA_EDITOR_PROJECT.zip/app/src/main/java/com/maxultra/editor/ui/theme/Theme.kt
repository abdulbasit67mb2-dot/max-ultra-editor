package com.maxultra.editor.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF6C5CE7),
    secondary = Color(0xFF00CEC9),
    background = Color(0xFF0F0F12),
    surface = Color(0xFF1B1B22)
)

@Composable
fun MaxUltraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColorScheme, content = content)
}
