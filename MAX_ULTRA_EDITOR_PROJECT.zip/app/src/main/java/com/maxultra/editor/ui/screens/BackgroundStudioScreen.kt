package com.maxultra.editor.ui.screens
import android.net.Uri
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun BackgroundStudioScreen(imageUri: Uri, onBack: () -> Unit) { Text("Background Studio") }
