package com.maxultra.editor.ui.screens
import android.net.Uri
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ObjectEraserScreen(imageUri: Uri, onBack: () -> Unit) { Text("Object Eraser") }
